﻿Module MdlServicevb
    Public L01 As New LibraryProc.Security
    Public FCOnfigurasi As New FrmConfigurasiServer
    'Public Regedit As String = New String("HKEY_CURRENT_USER\Softmed Consultindo\SFA")
    Public Regedit As String = New String("HKEY_CURRENT_USER\TugasAkhir\TA")
    Public JumDigitAutoNumber As String
    Public Query As String
End Module
