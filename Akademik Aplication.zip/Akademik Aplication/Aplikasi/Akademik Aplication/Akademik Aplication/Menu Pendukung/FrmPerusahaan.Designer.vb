﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmPerusahaan
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FrmPerusahaan))
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.TxtAlamat = New System.Windows.Forms.RichTextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Txtselogan = New System.Windows.Forms.TextBox()
        Me.TxtWeb = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtFax = New System.Windows.Forms.TextBox()
        Me.TxtKontak = New System.Windows.Forms.TextBox()
        Me.TxtNoTlpn = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.TxtEmail = New System.Windows.Forms.TextBox()
        Me.TxtProvinsi = New System.Windows.Forms.TextBox()
        Me.BtnSimpan = New System.Windows.Forms.PictureBox()
        Me.BtnKeluar = New System.Windows.Forms.PictureBox()
        Me.TxtNegara = New System.Windows.Forms.TextBox()
        Me.PicPerusahaan = New System.Windows.Forms.PictureBox()
        Me.KlikKanan = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.CariToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HapusToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TxtKota = New System.Windows.Forms.TextBox()
        Me.TxtNamaPerusahaan = New System.Windows.Forms.TextBox()
        Me.TxtIDPerusahaan = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        CType(Me.BtnSimpan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BtnKeluar, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicPerusahaan, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KlikKanan.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.Color.White
        Me.Label21.Location = New System.Drawing.Point(79, 54)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(442, 52)
        Me.Label21.TabIndex = 242
        Me.Label21.Text = resources.GetString("Label21.Text")
        Me.ToolTip1.SetToolTip(Me.Label21, resources.GetString("Label21.ToolTip"))
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.SteelBlue
        Me.Label24.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 6.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.White
        Me.Label24.Location = New System.Drawing.Point(563, 24)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(19, 9)
        Me.Label24.TabIndex = 314
        Me.Label24.Text = "logo"
        '
        'TxtAlamat
        '
        Me.TxtAlamat.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.TxtAlamat.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!)
        Me.TxtAlamat.Location = New System.Drawing.Point(159, 78)
        Me.TxtAlamat.MaxLength = 1000
        Me.TxtAlamat.Name = "TxtAlamat"
        Me.TxtAlamat.Size = New System.Drawing.Size(261, 41)
        Me.TxtAlamat.TabIndex = 312
        Me.TxtAlamat.Text = ""
        Me.ToolTip1.SetToolTip(Me.TxtAlamat, "Address")
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.Color.Black
        Me.Label23.Location = New System.Drawing.Point(143, 322)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(12, 16)
        Me.Label23.TabIndex = 311
        Me.Label23.Text = ":"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.Color.Black
        Me.Label22.Location = New System.Drawing.Point(143, 292)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(12, 16)
        Me.Label22.TabIndex = 310
        Me.Label22.Text = ":"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.Color.Black
        Me.Label17.Location = New System.Drawing.Point(143, 266)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(12, 16)
        Me.Label17.TabIndex = 308
        Me.Label17.Text = ":"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.Color.Black
        Me.Label16.Location = New System.Drawing.Point(143, 237)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(12, 16)
        Me.Label16.TabIndex = 307
        Me.Label16.Text = ":"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.Color.Black
        Me.Label15.Location = New System.Drawing.Point(25, 322)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(103, 15)
        Me.Label15.TabIndex = 306
        Me.Label15.Text = "Corporate Slogan"
        '
        'Txtselogan
        '
        Me.Txtselogan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Txtselogan.Location = New System.Drawing.Point(156, 320)
        Me.Txtselogan.MaxLength = 1000
        Me.Txtselogan.Multiline = True
        Me.Txtselogan.Name = "Txtselogan"
        Me.Txtselogan.Size = New System.Drawing.Size(434, 43)
        Me.Txtselogan.TabIndex = 303
        Me.ToolTip1.SetToolTip(Me.Txtselogan, "Corporate slogan")
        '
        'TxtWeb
        '
        Me.TxtWeb.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtWeb.Location = New System.Drawing.Point(156, 292)
        Me.TxtWeb.MaxLength = 1000
        Me.TxtWeb.Name = "TxtWeb"
        Me.TxtWeb.Size = New System.Drawing.Size(349, 22)
        Me.TxtWeb.TabIndex = 302
        Me.ToolTip1.SetToolTip(Me.TxtWeb, "Website")
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Black
        Me.Label2.Location = New System.Drawing.Point(25, 290)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(51, 15)
        Me.Label2.TabIndex = 298
        Me.Label2.Text = "Website"
        '
        'TxtFax
        '
        Me.TxtFax.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtFax.Location = New System.Drawing.Point(156, 263)
        Me.TxtFax.MaxLength = 1000
        Me.TxtFax.Name = "TxtFax"
        Me.TxtFax.Size = New System.Drawing.Size(199, 22)
        Me.TxtFax.TabIndex = 297
        Me.ToolTip1.SetToolTip(Me.TxtFax, "Fax")
        '
        'TxtKontak
        '
        Me.TxtKontak.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtKontak.Location = New System.Drawing.Point(328, 236)
        Me.TxtKontak.MaxLength = 1000
        Me.TxtKontak.Name = "TxtKontak"
        Me.TxtKontak.Size = New System.Drawing.Size(177, 22)
        Me.TxtKontak.TabIndex = 296
        Me.ToolTip1.SetToolTip(Me.TxtKontak, "Contact no")
        '
        'TxtNoTlpn
        '
        Me.TxtNoTlpn.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNoTlpn.Location = New System.Drawing.Point(156, 235)
        Me.TxtNoTlpn.MaxLength = 1000
        Me.TxtNoTlpn.Name = "TxtNoTlpn"
        Me.TxtNoTlpn.Size = New System.Drawing.Size(156, 22)
        Me.TxtNoTlpn.TabIndex = 295
        Me.ToolTip1.SetToolTip(Me.TxtNoTlpn, "Phone no")
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.Location = New System.Drawing.Point(25, 264)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 15)
        Me.Label1.TabIndex = 294
        Me.Label1.Text = "Fax"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.Black
        Me.Label4.Location = New System.Drawing.Point(25, 237)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(112, 15)
        Me.Label4.TabIndex = 293
        Me.Label4.Text = "Phone No \ Contact"
        '
        'TxtEmail
        '
        Me.TxtEmail.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtEmail.Location = New System.Drawing.Point(156, 207)
        Me.TxtEmail.MaxLength = 1000
        Me.TxtEmail.Name = "TxtEmail"
        Me.TxtEmail.Size = New System.Drawing.Size(265, 22)
        Me.TxtEmail.TabIndex = 292
        Me.ToolTip1.SetToolTip(Me.TxtEmail, "Email")
        '
        'TxtProvinsi
        '
        Me.TxtProvinsi.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtProvinsi.Location = New System.Drawing.Point(156, 180)
        Me.TxtProvinsi.MaxLength = 1000
        Me.TxtProvinsi.Name = "TxtProvinsi"
        Me.TxtProvinsi.Size = New System.Drawing.Size(265, 22)
        Me.TxtProvinsi.TabIndex = 291
        Me.ToolTip1.SetToolTip(Me.TxtProvinsi, "State")
        '
        'BtnSimpan
        '
        Me.BtnSimpan.BackColor = System.Drawing.Color.Transparent
        Me.BtnSimpan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnSimpan.Image = CType(resources.GetObject("BtnSimpan.Image"), System.Drawing.Image)
        Me.BtnSimpan.Location = New System.Drawing.Point(432, 20)
        Me.BtnSimpan.Name = "BtnSimpan"
        Me.BtnSimpan.Size = New System.Drawing.Size(108, 43)
        Me.BtnSimpan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BtnSimpan.TabIndex = 77
        Me.BtnSimpan.TabStop = False
        Me.ToolTip1.SetToolTip(Me.BtnSimpan, "Press this button to save data")
        '
        'BtnKeluar
        '
        Me.BtnKeluar.BackColor = System.Drawing.Color.Transparent
        Me.BtnKeluar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.BtnKeluar.Image = CType(resources.GetObject("BtnKeluar.Image"), System.Drawing.Image)
        Me.BtnKeluar.Location = New System.Drawing.Point(542, 20)
        Me.BtnKeluar.Name = "BtnKeluar"
        Me.BtnKeluar.Size = New System.Drawing.Size(108, 42)
        Me.BtnKeluar.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.BtnKeluar.TabIndex = 78
        Me.BtnKeluar.TabStop = False
        Me.ToolTip1.SetToolTip(Me.BtnKeluar, "Press this button to cancel")
        '
        'TxtNegara
        '
        Me.TxtNegara.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNegara.Location = New System.Drawing.Point(156, 125)
        Me.TxtNegara.MaxLength = 1000
        Me.TxtNegara.Name = "TxtNegara"
        Me.TxtNegara.Size = New System.Drawing.Size(217, 22)
        Me.TxtNegara.TabIndex = 285
        Me.ToolTip1.SetToolTip(Me.TxtNegara, "Country")
        '
        'PicPerusahaan
        '
        Me.PicPerusahaan.BackColor = System.Drawing.Color.SteelBlue
        Me.PicPerusahaan.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PicPerusahaan.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.PicPerusahaan.ContextMenuStrip = Me.KlikKanan
        Me.PicPerusahaan.Cursor = System.Windows.Forms.Cursors.Hand
        Me.PicPerusahaan.Location = New System.Drawing.Point(428, 21)
        Me.PicPerusahaan.Name = "PicPerusahaan"
        Me.PicPerusahaan.Size = New System.Drawing.Size(159, 208)
        Me.PicPerusahaan.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PicPerusahaan.TabIndex = 279
        Me.PicPerusahaan.TabStop = False
        Me.ToolTip1.SetToolTip(Me.PicPerusahaan, "Logo")
        '
        'KlikKanan
        '
        Me.KlikKanan.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CariToolStripMenuItem, Me.HapusToolStripMenuItem})
        Me.KlikKanan.Name = "KlikKanan"
        Me.KlikKanan.Size = New System.Drawing.Size(113, 48)
        '
        'CariToolStripMenuItem
        '
        Me.CariToolStripMenuItem.Image = CType(resources.GetObject("CariToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CariToolStripMenuItem.Name = "CariToolStripMenuItem"
        Me.CariToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.CariToolStripMenuItem.Text = "&Browse"
        '
        'HapusToolStripMenuItem
        '
        Me.HapusToolStripMenuItem.Image = CType(resources.GetObject("HapusToolStripMenuItem.Image"), System.Drawing.Image)
        Me.HapusToolStripMenuItem.Name = "HapusToolStripMenuItem"
        Me.HapusToolStripMenuItem.Size = New System.Drawing.Size(112, 22)
        Me.HapusToolStripMenuItem.Text = "&Delete"
        '
        'TxtKota
        '
        Me.TxtKota.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtKota.Location = New System.Drawing.Point(156, 152)
        Me.TxtKota.MaxLength = 1000
        Me.TxtKota.Name = "TxtKota"
        Me.TxtKota.Size = New System.Drawing.Size(196, 22)
        Me.TxtKota.TabIndex = 280
        Me.ToolTip1.SetToolTip(Me.TxtKota, "City")
        '
        'TxtNamaPerusahaan
        '
        Me.TxtNamaPerusahaan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtNamaPerusahaan.Location = New System.Drawing.Point(156, 49)
        Me.TxtNamaPerusahaan.MaxLength = 1000
        Me.TxtNamaPerusahaan.Name = "TxtNamaPerusahaan"
        Me.TxtNamaPerusahaan.Size = New System.Drawing.Size(265, 22)
        Me.TxtNamaPerusahaan.TabIndex = 277
        Me.ToolTip1.SetToolTip(Me.TxtNamaPerusahaan, "Corporate name")
        '
        'TxtIDPerusahaan
        '
        Me.TxtIDPerusahaan.BackColor = System.Drawing.Color.Linen
        Me.TxtIDPerusahaan.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TxtIDPerusahaan.Location = New System.Drawing.Point(156, 21)
        Me.TxtIDPerusahaan.MaxLength = 10
        Me.TxtIDPerusahaan.Name = "TxtIDPerusahaan"
        Me.TxtIDPerusahaan.ReadOnly = True
        Me.TxtIDPerusahaan.Size = New System.Drawing.Size(146, 22)
        Me.TxtIDPerusahaan.TabIndex = 276
        Me.ToolTip1.SetToolTip(Me.TxtIDPerusahaan, "Corporate ID")
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.SteelBlue
        Me.GroupBox1.Controls.Add(Me.BtnSimpan)
        Me.GroupBox1.Controls.Add(Me.BtnKeluar)
        Me.GroupBox1.Controls.Add(Me.Label21)
        Me.GroupBox1.Location = New System.Drawing.Point(-59, 379)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(689, 134)
        Me.GroupBox1.TabIndex = 290
        Me.GroupBox1.TabStop = False
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label29.ForeColor = System.Drawing.Color.Black
        Me.Label29.Location = New System.Drawing.Point(143, 207)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(12, 16)
        Me.Label29.TabIndex = 289
        Me.Label29.Text = ":"
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label28.ForeColor = System.Drawing.Color.Black
        Me.Label28.Location = New System.Drawing.Point(25, 180)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(91, 15)
        Me.Label28.TabIndex = 288
        Me.Label28.Text = "State \ Province"
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label27.ForeColor = System.Drawing.Color.Black
        Me.Label27.Location = New System.Drawing.Point(25, 208)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(39, 15)
        Me.Label27.TabIndex = 287
        Me.Label27.Text = "Email"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label26.ForeColor = System.Drawing.Color.Black
        Me.Label26.Location = New System.Drawing.Point(143, 180)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(12, 16)
        Me.Label26.TabIndex = 286
        Me.Label26.Text = ":"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.Black
        Me.Label9.Location = New System.Drawing.Point(24, 125)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 15)
        Me.Label9.TabIndex = 274
        Me.Label9.Text = "Country"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.Black
        Me.Label10.Location = New System.Drawing.Point(25, 151)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(26, 15)
        Me.Label10.TabIndex = 275
        Me.Label10.Text = "City"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.Black
        Me.Label8.Location = New System.Drawing.Point(24, 78)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(51, 15)
        Me.Label8.TabIndex = 273
        Me.Label8.Text = "Address"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.Black
        Me.Label7.Location = New System.Drawing.Point(23, 51)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(98, 15)
        Me.Label7.TabIndex = 272
        Me.Label7.Text = "Corporate Name"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.Black
        Me.Label5.Location = New System.Drawing.Point(23, 23)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(76, 15)
        Me.Label5.TabIndex = 271
        Me.Label5.Text = "Corporate ID"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.Color.Black
        Me.Label19.Location = New System.Drawing.Point(143, 150)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(12, 16)
        Me.Label19.TabIndex = 284
        Me.Label19.Text = ":"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.Color.Black
        Me.Label18.Location = New System.Drawing.Point(143, 124)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(12, 16)
        Me.Label18.TabIndex = 283
        Me.Label18.Text = ":"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.Color.Black
        Me.Label14.Location = New System.Drawing.Point(142, 78)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(12, 16)
        Me.Label14.TabIndex = 282
        Me.Label14.Text = ":"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.Color.Black
        Me.Label13.Location = New System.Drawing.Point(143, 50)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(12, 16)
        Me.Label13.TabIndex = 281
        Me.Label13.Text = ":"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.Black
        Me.Label6.Location = New System.Drawing.Point(143, 23)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(12, 16)
        Me.Label6.TabIndex = 278
        Me.Label6.Text = ":"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.Black
        Me.Label3.Location = New System.Drawing.Point(315, 238)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(12, 16)
        Me.Label3.TabIndex = 304
        Me.Label3.Text = "\"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(156, 76)
        Me.TextBox1.MaxLength = 50
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(265, 44)
        Me.TextBox1.TabIndex = 313
        '
        'FrmPerusahaan
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(604, 506)
        Me.Controls.Add(Me.Label24)
        Me.Controls.Add(Me.TxtAlamat)
        Me.Controls.Add(Me.Label23)
        Me.Controls.Add(Me.Label22)
        Me.Controls.Add(Me.Label17)
        Me.Controls.Add(Me.Label16)
        Me.Controls.Add(Me.Label15)
        Me.Controls.Add(Me.Txtselogan)
        Me.Controls.Add(Me.TxtWeb)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.TxtFax)
        Me.Controls.Add(Me.TxtKontak)
        Me.Controls.Add(Me.TxtNoTlpn)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.TxtEmail)
        Me.Controls.Add(Me.TxtProvinsi)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label29)
        Me.Controls.Add(Me.Label28)
        Me.Controls.Add(Me.Label27)
        Me.Controls.Add(Me.Label26)
        Me.Controls.Add(Me.TxtNegara)
        Me.Controls.Add(Me.PicPerusahaan)
        Me.Controls.Add(Me.TxtKota)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.TxtNamaPerusahaan)
        Me.Controls.Add(Me.TxtIDPerusahaan)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label19)
        Me.Controls.Add(Me.Label18)
        Me.Controls.Add(Me.Label14)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.KeyPreview = True
        Me.Name = "FrmPerusahaan"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu Perusahaan"
        CType(Me.BtnSimpan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BtnKeluar, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicPerusahaan, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KlikKanan.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents TxtAlamat As System.Windows.Forms.RichTextBox
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Txtselogan As System.Windows.Forms.TextBox
    Friend WithEvents TxtWeb As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtFax As System.Windows.Forms.TextBox
    Friend WithEvents TxtKontak As System.Windows.Forms.TextBox
    Friend WithEvents TxtNoTlpn As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TxtEmail As System.Windows.Forms.TextBox
    Friend WithEvents TxtProvinsi As System.Windows.Forms.TextBox
    Friend WithEvents BtnSimpan As System.Windows.Forms.PictureBox
    Friend WithEvents BtnKeluar As System.Windows.Forms.PictureBox
    Friend WithEvents TxtNegara As System.Windows.Forms.TextBox
    Friend WithEvents PicPerusahaan As System.Windows.Forms.PictureBox
    Friend WithEvents KlikKanan As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents CariToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HapusToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TxtKota As System.Windows.Forms.TextBox
    Friend WithEvents TxtNamaPerusahaan As System.Windows.Forms.TextBox
    Friend WithEvents TxtIDPerusahaan As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
End Class
